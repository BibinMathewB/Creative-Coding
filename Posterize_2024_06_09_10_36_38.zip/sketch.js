let img;

function preload() {
  img = loadImage('Nature1.jpg'); 
}

function setup() {
  createCanvas(800, 600);
  noLoop();
}

function draw() {
  background(255);
  image(img, 0, 0, width / 2, height);
  img.loadPixels();

  
  let levels = 3; // Number of color levels

  for (let y = 0; y < img.height; y++) {
    for (let x = 0; x < img.width; x++) {
      let index = (x + y * img.width) * 4;
      img.pixels[index] = posterize(img.pixels[index], levels);       
      img.pixels[index + 1] = posterize(img.pixels[index + 1], levels); 
      img.pixels[index + 2] = posterize(img.pixels[index + 2], levels);
    }
  }

  
  img.updatePixels();

  
  image(img, width / 2, 0, width / 2, height);
}


function posterize(value, levels) {
  let step = 255 / (levels - 1);
  return round(value / step) * step;
}
