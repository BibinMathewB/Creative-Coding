function setup() {
  createCanvas(800, 800);
  noLoop();
}

function draw() {
  background(255);
  let patternSize = 100; 

  for (let x = 0; x < width; x += patternSize) {
    for (let y = 0; y < height; y += patternSize) {
      drawPattern(x, y, patternSize);
    }
  }
}

function drawPattern(x, y, size) {
  // Colors of the pattern
  let colors = [
    color(255, 102, 102),
    color(102, 255, 102),
    color(102, 102, 255),
    color(255, 255, 102),
    color(255, 102, 255),
    color(102, 255, 255)
  ];

  let c1 = random(colors);
  let c2 = random(colors);
  noStroke();
  fill(c1);
  rect(x, y, size, size);

  fill(c2);
  ellipse(x + size / 2, y + size / 2, size / 2, size / 2);

  stroke(255);
  strokeWeight(2);
  line(x, y, x + size, y + size);
  line(x + size, y, x, y + size);

  
  noStroke();
  fill(255);
  rect(x + size / 4, y + size / 4, size / 2, size / 2);
}
