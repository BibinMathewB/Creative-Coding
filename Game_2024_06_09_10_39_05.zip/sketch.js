let basket;
let objects = [];
let score = 0;

function setup() {
  createCanvas(800, 600);
  basket = new Basket();
}

function draw() {
  background(200);

  // Display and update the basket
  basket.display();
  basket.update();

  // Display and update the falling objects
  for (let i = objects.length - 1; i >= 0; i--) {
    objects[i].display();
    objects[i].update();

    // Check for catching objects
    if (objects[i].caught()) {
      objects.splice(i, 1);
      score++;
    } else if (objects[i].y > height) {
      objects.splice(i, 1);
    }
  }

  // Occasionally add new objects
  if (frameCount % 60 === 0) {
    objects.push(new FallingObject());
  }

  // Display the score
  fill(0);
  textSize(24);
  text("Score: " + score, width - 100, 50);
}

class Basket {
  constructor() {
    this.x = width / 2;
    this.y = height - 20;
    this.width = 100;
    this.height = 20;
  }

  display() {
    fill(150);
    rect(this.x, this.y, this.width, this.height);
  }

  update() {
    if (keyIsDown(LEFT_ARROW)) {
      this.x -= 5;
    }

    if (keyIsDown(RIGHT_ARROW)) {
      this.x += 5;
    }

    this.x = constrain(this.x, 0, width - this.width);
  }
}

class FallingObject {
  constructor() {
    this.x = random(width);
    this.y = 0;
    this.size = 20;
    this.speed = 3;
  }

  display() {
    fill(255, 0, 0);
    ellipse(this.x, this.y, this.size);
  }

  update() {
    this.y += this.speed;
  }

  caught() {
    return (
      this.y + this.size / 2 > basket.y &&
      this.x > basket.x &&
      this.x < basket.x + basket.width
    );
  }
}
