let trails = [];

function setup() {
  createCanvas(800, 600);
  noStroke();
}

function draw() {
  background(255, 50);

  let newTrail = {
    x: mouseX,
    y: mouseY,
    size: random(50, 50),
    color: color(random(255), random(255), random(255), 150)
  };
  trails.push(newTrail);

  if (trails.length > 50) {
    trails.shift();
  }

  for (let i = 0; i < trails.length; i++) {
    fill(trails[i].color);
    ellipse(trails[i].x, trails[i].y, trails[i].size);
  }
}
