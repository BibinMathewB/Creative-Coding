function setup() {
  createCanvas(800, 400);
  noLoop();
}

function draw() {
  background(200);

  // Car body
  fill(255, 0, 0);
  noStroke();
  rect(150, 200, 500, 100, 20);

  // Car roof
  quad(250, 200, 550, 200, 500, 150, 300, 150);

  // Windows
  fill(0, 100, 255, 150);
  quad(270, 200, 530, 200, 490, 160, 310, 160);
  fill(0, 0, 0, 100);
  quad(230, 200, 270, 200, 310, 160, 250, 160);
  quad(530, 200, 570, 200, 490, 160, 550, 160);

  // Wheels
  fill(50);
  ellipse(250, 320, 80, 80);
  ellipse(550, 320, 80, 80);
  
  // Wheel centers
  fill(100);
  ellipse(250, 320, 40, 40);
  ellipse(550, 320, 40, 40);

  // Headlights
  fill(255, 255, 0);
  ellipse(170, 250, 20, 20);
  ellipse(630, 250, 20, 20);

  // Tail lights
  fill(255, 0, 0);
  ellipse(140, 250, 20, 20);
  ellipse(660, 250, 20, 20);

  // Details (doors)
  stroke(0);
  strokeWeight(2);
  line(350, 200, 350, 300);
  line(450, 200, 450, 300);
}

