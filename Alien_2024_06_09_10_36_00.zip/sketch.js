function setup() {
  createCanvas(800, 600);
  noLoop();
}

function draw() {
  background(0, 0, 50);

  // Alien body
  fill(100, 255, 100);
  noStroke();
  ellipse(400, 400, 200, 300);

  // Alien head
  fill(150, 255, 150);
  ellipse(400, 250, 150, 200);

  // Alien eyes
  fill(255);
  ellipse(370, 220, 40, 60);
  ellipse(430, 220, 40, 60);
  
  fill(0);
  ellipse(370, 220, 20, 30);
  ellipse(430, 220, 20, 30);

  // Alien antennae
  stroke(150, 255, 150);
  strokeWeight(10);
  line(350, 150, 300, 50);
  line(450, 150, 500, 50);

  // Antennae tips
  fill(255, 0, 0);
  ellipse(300, 50, 20, 20);
  ellipse(500, 50, 20, 20);

  // Alien mouth
  noStroke();
  fill(255, 100, 100);
  ellipse(400, 300, 80, 40);

  // Alien spots
  fill(50, 200, 50);
  ellipse(360, 450, 30, 30);
  ellipse(440, 480, 40, 40);
  ellipse(400, 530, 50, 50);

  // Alien arms
  stroke(100, 255, 100);
  strokeWeight(20);
  line(300, 400, 200, 300);
  line(500, 400, 600, 300);

  // Alien legs
  line(350, 500, 300, 600);
  line(450, 500, 500, 600);

}
