let song;
let fft;

function preload() {
  // Load a sound file
  song = loadSound('Haha-sound-effect.mp3');
}

function setup() {
  createCanvas(800, 600);
  noFill();
  
  // Create an FFT object to analyze the sound
  fft = new p5.FFT();
  
  // Start playing the sound
  song.loop();
}

function draw() {
  background(0);

  // Get the amplitude spectrum
  let spectrum = fft.analyze();

  // Draw the spectrum as a waveform
  stroke(255);
  beginShape();
  for (let i = 0; i < spectrum.length; i++) {
    let x = map(i, 0, spectrum.length, 0, width);
    let y = map(spectrum[i], 0, 255, height, 0);
    vertex(x, y);
  }
  endShape();
}

function mousePressed() {
  if (song.isPlaying()) {
    song.pause();
  } else {
    song.loop();
  }
}
