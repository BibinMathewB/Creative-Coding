let data = [23, 45, 56, 78, 12, 89, 67, 34, 45, 56, 67, 78];
let labels = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

function setup() {
  createCanvas(800, 600);
  textAlign(CENTER, CENTER);
}

function draw() {
  background(255);
  let barWidth = width / data.length;

   for (let i = 0; i < data.length; i++) {
    let x = i * barWidth;
    let y = height - data[i] * 4; // Scale the data values for better visualization
    fill(100, 150, 200);
    rect(x, y, barWidth - 10, data[i] * 4);
    fill(0);
    text(labels[i], x + barWidth / 2, height - 10);
  }

  for (let i = 0; i <= 100; i += 10) {
    let y = height - i * 4;
    fill(0);
    text(i, 20, y);
    stroke(200);
    line(30, y, width, y);
  }
}
